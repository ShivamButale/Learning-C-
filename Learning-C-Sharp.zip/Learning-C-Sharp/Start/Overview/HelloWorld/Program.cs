﻿// See https://aka.ms/new-console-template for more information
using System;
Console.WriteLine("Hello, World!");
Console.WriteLine("What is your name?");
string str = Console.ReadLine();
Console.WriteLine("Why, hello there "+str);