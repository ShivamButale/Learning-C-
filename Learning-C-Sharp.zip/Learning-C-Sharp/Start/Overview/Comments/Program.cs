﻿
// Single line 
// u can add many of these 

using System;


internal class Program
{
    /// XML Comments are used to help provide documentation
    /// They start with triple-slashes and have a special syntax
    /// <summary>
    /// XML Comments are used to help provide documentation
    /// </summary>
    /// <param name="args"></param>
    /// <returns>
    /// No return value 
    /// </returns>
    private static void Main(string[] args)
    {
        Console.WriteLine("Hello World!");
    }
}
/* Multi 
   Line 
   Comment 
*/
