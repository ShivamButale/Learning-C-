﻿using System;

namespace MultiValues
{
    class Program
    {
        static void Main(string[] args)
        {
            // TODO: Tuples are grouped values added in C# 7
            (int a, int b) tup1 = (5, 10);
            var tup2 = ("some text", 10.5f);

            // TODO: Tuple values are mutable
            tup1.b = 500;
            tup2.Item1 = "NEW";
            tup2.Item2 = 43.5f;
            Console.WriteLine(tup1);
            Console.WriteLine(tup2);

        
            // TODO: Functions can work with tuples
           (int, int) result = PlusTimes(8,9);
           Console.WriteLine($"{result.Item1}, {result.Item2}");

        }

    // TODO: Functions can return multiple values using tuples
        static (int, int) PlusTimes(int a, int b) {
            return (a+b, a*b);
        }
    }
}
